package pgdp.colony;

import static pgdp.MiniJava.*;

public class PenguinColony {
	// Constants
	static final int ADULT_AGE = 1;
	static final int DAYS_PER_YEAR = 5;

}
