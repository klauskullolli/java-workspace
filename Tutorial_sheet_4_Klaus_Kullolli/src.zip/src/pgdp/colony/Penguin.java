package pgdp.colony;

import static pgdp.MiniJava.*;

public class Penguin {
    //Constants
    static final int MAX_HEALTH = 50;

}
