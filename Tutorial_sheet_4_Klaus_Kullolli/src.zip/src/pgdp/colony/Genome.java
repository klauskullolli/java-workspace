package pgdp.colony;

import static pgdp.MiniJava.*;

public class Genome {
    // Constants
    private static final int LENGTH = 13; //length of the String dna

}
